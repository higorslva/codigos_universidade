public class Relatorio{
    public void media_idade(){
        
    }
}