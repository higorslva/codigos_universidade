import javax.swing.*;

public class CamaroteSuperior extends VIP{
    public void imprimirValorIngresso(){
        JOptionPane.showInputDialog("Valor do ingresso VIP superior: R$" + getValorIngresso());
    }
}
