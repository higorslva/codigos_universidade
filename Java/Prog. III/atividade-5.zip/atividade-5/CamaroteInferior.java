import javax.swing.*;

public class CamaroteInferior extends VIP{
    public void imprimirValorIngresso(){
        JOptionPane.showInputDialog("Valor do ingresso VIP inferior: R$" + getValorIngresso());
    }
}
