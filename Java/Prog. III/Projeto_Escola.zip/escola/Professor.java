public class Professor extends Servidor{
    protected String especialidade;
    
    public void setEspecialidade(String especialidade){
        this.especialidade = especialidade;
    }
    
    public String getEspecialidade(){
        return this.especialidade;
    }
}
