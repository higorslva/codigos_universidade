import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        
        Pessoa p1 = new Pessoa();
        //System.out.println("Qual o seu nome?");
        //Scanner input = new Scanner (System.in);
        //p1.nome = input.next();
        p1.informaNome();
        
        p1.calculaIdade();
        
        p1.informaIdade();
        
        p1.AlbertEinstein();
        
        p1.IsaacNewton();
  }
}  