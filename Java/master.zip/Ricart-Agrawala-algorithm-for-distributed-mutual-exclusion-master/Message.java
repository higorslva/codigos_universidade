
public enum Message {

	REQUEST,REPLY,READY,INITIATE,PERMIT;
	
}
