

public class Node {

	int id;
	String ipaddr;
	int portno;
}
